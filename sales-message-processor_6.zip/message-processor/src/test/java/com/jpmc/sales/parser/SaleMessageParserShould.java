package com.jpmc.sales.parser;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.jpmc.sales.domain.Item;
import com.jpmc.sales.processor.ProcessingException;

public class SaleMessageParserShould {

Parser parser = null;
	
	@BeforeEach
	public void beforeEach() {
		parser = new SaleMessageParser();
	}
	
	@Test
	public void workAsExpectedWithCorrectInputs() {
		
		String sale = "Apple at 10p";
		Item item = parser.apply(sale.split("\\s+"));
		assertAll(
			() -> assertNull(item.getOperator()),
			() -> assertEquals(BigDecimal.valueOf(0.1), item.getPrice()),
			() -> assertEquals("apples", item.getProduct()),
			() -> assertEquals(1, item.getQuantity())
		);
	}
	
	
	@Test
	public void shouldThrowExceptionOnEmptySaleMessage() {
		assertThrows(ProcessingException.class, ()->parser.apply(new String[0]));
	}
}
