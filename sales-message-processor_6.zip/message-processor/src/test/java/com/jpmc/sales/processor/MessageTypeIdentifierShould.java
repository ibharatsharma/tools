package com.jpmc.sales.processor;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.function.Function;

import org.junit.jupiter.api.Test;

import com.jpmc.sales.utils.Constants;

/**
 * Tests {@code MessageTypeIdentifier}
 * 
 * @author Bharat
 *
 */
public class MessageTypeIdentifierShould {

	private final Function<String[], String> typeIdentifier = new MessageTypeIdentifier();

	@Test
	public void identifySalesMessageType() {

		String[] msgArr = "Apple at 10p".toLowerCase().split(Constants.SPACE_REGEX);
		String type = typeIdentifier.apply(msgArr);
		assertEquals(Constants.SALE, type);

	}
	
	@Test
	public void identifyBulkSalesMessageType() {

		String[] msgArr = "20 sales of apples at 10p each".toLowerCase().split(Constants.SPACE_REGEX);
		String type = typeIdentifier.apply(msgArr);
		assertEquals(Constants.BULK, type);

	}
	
	@Test
	public void identifyAdjustmentMessageType() {

		String[] msgArr = "Subtract 2p Bananas".toLowerCase().split(Constants.SPACE_REGEX);
		String type = typeIdentifier.apply(msgArr);
		assertEquals(Constants.ADJUSTMENT, type);

	}
	
	@Test
	public void returnNullForEmptyMessage() {

		String[] msgArr = "".toLowerCase().split(Constants.SPACE_REGEX);
		String type = typeIdentifier.apply(msgArr);
		assertNull(type);

	}
}
