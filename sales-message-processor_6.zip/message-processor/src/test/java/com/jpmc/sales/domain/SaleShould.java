package com.jpmc.sales.domain;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.jpmc.sales.processor.AdjustmentMaker;

/**
 * 
 * @author Bharat
 *
 */
public class SaleShould {
	
	private Sale sale;
	
	@BeforeEach
	public void setup() {

		sale = new Sale();
		sale.addItem(new Item("apples", BigDecimal.valueOf(0.25), 1, null));
		sale.addItem(new Item("apples", BigDecimal.valueOf(0.25), 1, null));
		sale.addItem(new Item("apples", BigDecimal.valueOf(0.25), 5, null));
		
	}
	
	@Test
	public void returnCorrectTotalValueAndQuantity() {
		
		assertAll(
			() -> assertEquals(7, sale.getTotalQuantity()),
			()-> assertEquals(BigDecimal.valueOf(1.75).setScale(2), sale.getTotalValue())
		);
	}
	
	@Test
	public void shouldApplyCorrectAdjustmentsToGivenSale() {
		AdjustmentMaker adj = new AdjustmentMaker(BigDecimal.valueOf(1.0), "add"); 
		sale.applyAdjustment(adj);
		assertAll(
				() -> assertEquals(7, sale.getTotalQuantity()),
				()-> assertEquals(BigDecimal.valueOf(8.75).setScale(2), sale.getTotalValue())
			);
	}
}
