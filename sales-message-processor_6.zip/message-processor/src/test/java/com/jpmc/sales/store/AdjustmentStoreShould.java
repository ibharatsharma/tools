package com.jpmc.sales.store;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Test class for {@code AdjustmentStore}
 * @author Bharat
 *
 */
public class AdjustmentStoreShould {

	private AdjustmentStore store;
	
	@BeforeEach
	public void beforeEach() {
		store = new AdjustmentStoreImpl();
	}
	
	@Test
	public void saveAndReturnCorrectAdjustmentCount() {
		store.recordAdjustment("test");
		assertEquals(1, store.getAdjustments().size());
	}
	
}
