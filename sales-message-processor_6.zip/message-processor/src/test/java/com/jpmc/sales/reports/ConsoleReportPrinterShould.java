package com.jpmc.sales.reports;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.jpmc.sales.domain.Item;
import com.jpmc.sales.domain.Sale;

/**
 * Tests {@Code ConsoleReportPrinter}
 * 
 * @author Bharat
 *
 */
public class ConsoleReportPrinterShould {

	private ReportPrinter printer;

	@BeforeEach
	public void beforeEach() {
		printer = new ConsoleReportPrinter();
	}

	@Test
	public void printReportForValidInput() throws IOException {
		PrintStream originalOut = System.out;
		try {
			
			final String EXPECTED_OUTPUT_FILE = "sales/expected-console-out.txt";
			final String ACTUAL_OUTPUT_FILE = "sales/console-out.txt";
			// delete any existing file
			Files.deleteIfExists(Paths.get(ACTUAL_OUTPUT_FILE));

			PrintStream ps = new PrintStream(new File(ACTUAL_OUTPUT_FILE));
			System.setOut(ps);
			Map<String, Sale> data = new HashMap<>();

			Sale sale = new Sale();
			sale.addItem(new Item("apples", BigDecimal.valueOf(0.25), 5, null));
			data.put("apples", sale);
			printer.print(data);
			ps.flush();
			ps.close();

			byte[] expected = Files.readAllBytes(Paths.get(EXPECTED_OUTPUT_FILE));
			byte[] actual = Files.readAllBytes(Paths.get(ACTUAL_OUTPUT_FILE));
			assertTrue(Arrays.equals(expected, actual));
		} catch (IOException e) {
			fail(e.getMessage());
		}finally {
			System.setOut(originalOut);
		}
	}
	
	@Test
	public void printAdjustmentsReport() throws IOException {
		PrintStream originalOut = System.out;
		try {
			
			final String EXPECTED_OUTPUT_FILE = "sales/expected-adj-console-out.txt";
			final String ACTUAL_OUTPUT_FILE = "sales/adj-console-out.txt";
			// delete any existing file
			Files.deleteIfExists(Paths.get(ACTUAL_OUTPUT_FILE));

			PrintStream ps = new PrintStream(new File(ACTUAL_OUTPUT_FILE));
			System.setOut(ps);

			List<String> adjustments = new ArrayList<>();
			adjustments.add("Performed add 0.2 to 49 apples and price adjusted from 11.90 to 21.70");
			printer.printAdjustments(adjustments);
			ps.flush();
			ps.close();

			byte[] expected = Files.readAllBytes(Paths.get(EXPECTED_OUTPUT_FILE));
			byte[] actual = Files.readAllBytes(Paths.get(ACTUAL_OUTPUT_FILE));
			assertTrue(Arrays.equals(expected, actual));
		} catch (IOException e) {
			fail(e.getMessage());
		}finally {
			System.setOut(originalOut); 
		}
	}
}
