package com.jpmc.sales.parser;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class ParserTest {

	public Parser parser;
	
	@Test
	public void parseTypeTest() {
		parser = new SaleMessageParser();
		assertAll(
		() -> assertEquals("mangoes", parser.parseType("mango")),
		() -> assertEquals("berries", parser.parseType("berry")),
		() -> assertEquals("bananas", parser.parseType("banana")),
		() -> assertEquals("cherries", parser.parseType("cherry")),
		() -> assertEquals("churches", parser.parseType("church")));
	}
	
}
