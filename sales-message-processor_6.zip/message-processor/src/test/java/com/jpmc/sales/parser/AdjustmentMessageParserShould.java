package com.jpmc.sales.parser;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.jpmc.sales.domain.Item;
import com.jpmc.sales.processor.ProcessingException;
/**
 * Test class for {@code AdjustmentMessageParser}
 * 
 * @author Bharat
 *
 */
public class AdjustmentMessageParserShould {

	Parser parser = null;
	
	@BeforeEach
	public void beforeEach() {
		parser = new AdjustmentMessageParser();
	}
	
	@Test
	public void workAsExpectedWithCorrectInputs() {
		
		String adjustment = "Subtract 2p Bananas";
		Item item = parser.apply(adjustment.split("\\s+"));
		assertAll(
			() -> assertEquals("Subtract", item.getOperator()),
			() -> assertEquals(BigDecimal.valueOf(0.02), item.getPrice()),
			() -> assertEquals("bananas", item.getProduct()),
			() -> assertEquals(0, item.getQuantity())
		);
	}
	
	
	@Test
	public void throwExceptionForEmptyAdjustmentInput() {
		assertThrows(ProcessingException.class, () -> parser.apply(new String[0]));
	}
}
