package com.jpmc.sales.parser;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.jpmc.sales.domain.Item;
import com.jpmc.sales.processor.ProcessingException;

/**
 * Test class for {@code BulkSaleMessageParser}
 * @author Bharat
 *
 */
public class BulkSaleMessageParserShould {
	
	Parser parser = null;
	
	@BeforeEach
	public void beforeEach() {
		parser = new BulkSaleMessageParser();
	}
	
	@Test
	public void workAsExpectedWithCorrectInputs() {
		
		String bulk = "20 sales of apples at 10p each";
		Item item = parser.apply(bulk.split("\\s+"));
		assertAll(
			() -> assertNull(item.getOperator()),
			() -> assertEquals(BigDecimal.valueOf(0.1), item.getPrice()),
			() -> assertEquals("apples", item.getProduct()),
			() -> assertEquals(20, item.getQuantity())
		);
	}
	
	
	@Test
	public void shouldThrowExceptionOnEmptyBulkMessage() {
		assertThrows(ProcessingException.class, ()->parser.apply(new String[0]));
	}
}
