package com.jpmc.sales.store;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.math.BigDecimal;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.jpmc.sales.domain.Item;

/**
 * Tests {@code SalesStore}
 * 
 * @author Bharat
 *
 */
public class SalesStoreShould {

	private static SalesStore store;
	
	@BeforeAll
	public static void setup() {
		store = SalesStoreImpl.getInstance();
		store.saveItem(new Item("apples", BigDecimal.valueOf(0.25), 5, null));
	}
	
	
	@Test
	public void saveAndReturnItemsAsPerInput() {
		
		assertEquals(1, store.getAllItems().size());
	}
	
	@Test
	public void returnItemByType() {
		
		assertAll(
				() -> assertNotNull(store.getSaleForItem("apples")),
				() -> assertEquals(5, store.getSaleForItem("apples").getTotalQuantity()),
				() -> assertEquals(BigDecimal.valueOf(1.25).setScale(2), store.getSaleForItem("apples").getTotalValue())
			);
	}
}
