package com.jpmc.sales.processor;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.jpmc.sales.domain.Item;
import com.jpmc.sales.store.SalesStore;
import com.jpmc.sales.store.SalesStoreImpl;

/**
 * Test class for {@code AdjustmentService}
 * @author Bharat
 *
 */
public class AdjustmentServiceShould {

	private AdjustmentService service;
	private SalesStore salesStore;

	@BeforeEach
	public void beforeEach() {
		service = new AdjustmentService();
		this.salesStore = SalesStoreImpl.getInstance();
	}

	@Test
	public void returnAdjustmentsFromStore() {
		this.service.recordAdjustment("Performed add 0.2 to 28 apples and price adjusted from  4.20 to  9.80");
		List<String> adjustments = this.service.getAdjustments();
		assertEquals(1, adjustments.size());
	}

	@Test
	public void silentlyIgnoreAdjustmentWhenThereIsNoSaleForGivenProduct() {

		Item m = new Item();
		m.setOperator("add");
		m.setProduct("mangoes");
		m.setQuantity(0); // this is an adjustment msg
		m.setPrice(new BigDecimal(1.5));
		this.service.handleAdjustmentMessage(m);
		assertEquals(0, this.service.getAdjustments().size());

	}

	@Test
	public void recordAdjustment() {
		Item sale = new Item();

		sale.setProduct("mangoes");
		sale.setQuantity(1); // this is an adjustment msg
		sale.setPrice(new BigDecimal(1.5));
		salesStore.saveItem(sale);

		Item m = new Item();
		m.setOperator("add");
		m.setProduct("mangoes");
		m.setQuantity(0); // this is an adjustment msg
		m.setPrice(new BigDecimal(0.5));
		this.service.handleAdjustmentMessage(m);

		assertEquals(1, this.service.getAdjustments().size());
		assertEquals(1, this.salesStore.getSaleForItem("mangoes").getTotalQuantity());
		assertEquals(BigDecimal.valueOf(2.00).setScale(2), this.salesStore.getSaleForItem("mangoes").getTotalValue());

		this.salesStore.getAllItems().remove("mangoes");
	}

}
