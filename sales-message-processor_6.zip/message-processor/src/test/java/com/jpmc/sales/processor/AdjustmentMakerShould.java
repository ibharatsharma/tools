package com.jpmc.sales.processor;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.jpmc.sales.domain.Item;
import com.jpmc.sales.domain.Sale;

/**
 * Tests {@code AdjustmentMaker}
 * 
 * @author Bharat
 *
 */
public class AdjustmentMakerShould {

private Sale sale;
	
	@BeforeEach
	public void setup() {

		sale = new Sale();
		sale.addItem(new Item("apples", BigDecimal.valueOf(0.25), 1, null));
		sale.addItem(new Item("apples", BigDecimal.valueOf(0.25), 1, null));
		sale.addItem(new Item("apples", BigDecimal.valueOf(0.25), 5, null));
		
	}
	
	@Test
	public void doAdjustmentToASaleForAddOperation() {
		AdjustmentMaker adjMaker = new AdjustmentMaker(BigDecimal.valueOf(0.10), "add");
		sale.applyAdjustment(adjMaker);
		
		assertAll(
				() -> assertEquals(7, sale.getTotalQuantity()),
				()-> assertEquals(BigDecimal.valueOf(2.45), sale.getTotalValue())
			);
	}
	
	
	@Test
	public void doAdjustmentToASaleForSubtractOperation() {
		AdjustmentMaker adjMaker = new AdjustmentMaker(BigDecimal.valueOf(0.05), "subtract");
		sale.applyAdjustment(adjMaker);
		
		assertAll(
				() -> assertEquals(7, sale.getTotalQuantity()),
				()-> assertEquals(BigDecimal.valueOf(1.4).setScale(2), sale.getTotalValue())
			);
	}
	
	@Test
	public void doAdjustmentToASaleForMultiplyOperation() {
		AdjustmentMaker adjMaker = new AdjustmentMaker(BigDecimal.valueOf(1.2), "multiply");
		sale.applyAdjustment(adjMaker);
		
		assertAll(
				() -> assertEquals(7, sale.getTotalQuantity()),
				() -> assertEquals(BigDecimal.valueOf(2.1).setScale(2), sale.getTotalValue())
			);
	}
}
