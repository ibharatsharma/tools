package com.jpmc.sales.reports;

import java.util.List;
import java.util.Map;

import com.jpmc.sales.domain.Sale;

public interface ReportPrinter {

	public void print(Map<String, Sale> store);
	
	public void printAdjustments(List<String> adjustments);
}
