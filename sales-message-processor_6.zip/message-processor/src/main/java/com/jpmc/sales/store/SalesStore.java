package com.jpmc.sales.store;

import java.util.Map;

import com.jpmc.sales.domain.Item;
import com.jpmc.sales.domain.Sale;

public interface SalesStore {

	public void saveItem(Item m);

	public Map<String, Sale> getAllItems();

	public Sale getSaleForItem(String name);

}
