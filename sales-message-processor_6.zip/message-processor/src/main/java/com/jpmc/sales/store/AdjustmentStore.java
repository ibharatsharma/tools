package com.jpmc.sales.store;

import java.util.List;

public interface AdjustmentStore {

	public void recordAdjustment(String adjustment);

	public List<String> getAdjustments();
}
