package com.jpmc.sales;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.function.Consumer;
import java.util.stream.Stream;

import com.jpmc.sales.processor.MessageProcessor;

/**
 * The sale processor application
 * 
 * @author Bharat
 */
public class SalesProcessor {
	
	public static void main(String[] args) {
		// read input file received from 3rd party vendor
		try (Stream<String> messages = Files.lines(Paths.get("sales/sales.txt"))) {
			Consumer<String> consumer = new MessageProcessor();
			messages.forEach(consumer);
			System.out.println("*******************done*******************");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
