package com.jpmc.sales.processor;

/**
 * Custom exception
 * 
 * @author Bharat
 *
 */
public class ProcessingException extends RuntimeException {

	private static final long serialVersionUID = 5203188391682075715L;

	public ProcessingException() {
	}

	public ProcessingException(String message) {
		super(message);
	}
	
	public ProcessingException(String message, Throwable t) {
		super(message, t);
	}
}
