package com.jpmc.sales.processor;

import java.math.BigDecimal;
import java.util.List;
import java.util.function.Function;

import com.jpmc.sales.domain.Item;
import com.jpmc.sales.domain.Sale;
import com.jpmc.sales.store.AdjustmentStore;
import com.jpmc.sales.store.AdjustmentStoreImpl;
import com.jpmc.sales.store.SalesStore;
import com.jpmc.sales.store.SalesStoreImpl;

/**
 * 
 * @author Bharat
 *
 */
public class AdjustmentService {

	private final AdjustmentStore adjustmentStore;
	private final SalesStore salesStore;
	private static final int TEN = 10;
	private static final int FIFTY = 50;
	
	
	
	public AdjustmentService() {
		this.adjustmentStore = new AdjustmentStoreImpl();
		this.salesStore = SalesStoreImpl.getInstance();
	}
	
	public void recordAdjustment(String adjustment) {
		this.adjustmentStore.recordAdjustment(adjustment);
	}
	
	public List<String> getAdjustments() {
		return this.adjustmentStore.getAdjustments();
	}
	
	public void handleAdjustmentMessage(Item item) {
		Function<Item,Item> adjustment = new AdjustmentMaker(item.getPrice(), item.getOperator());
		Sale sale = salesStore.getSaleForItem(item.getProduct());
		BigDecimal oldPrice = BigDecimal.ZERO;
		if (sale != null) {
			oldPrice = sale.getTotalValue();
			sale.applyAdjustment(adjustment);
			this.recordAdjustmentMessage(oldPrice, sale, item);
		} else {
			//System.out.println("Can't do adjustment. No previous sale recorded for item: " + item);
			//throw new ProcessingException("Can't do adjustment. No previous sale recorded for item: " + item);
			// Assuming it is ok to silently ignore this case as there is no sale for this product.
		}
	}
	
	public void recordAdjustmentMessage(BigDecimal oldPrice, Sale sale, Item item) {
		
		String adjMsg = "Performed "+ item.getOperator() +" "
				+ item.getPrice() + " to "
				+ sale.getTotalQuantity()+ " " 
				+ item.getProduct() + " and price adjusted from "
				+ String.format("%5.2f",oldPrice) + " to "+ String.format("%5.2f",sale.getTotalValue());
		adjustmentStore.recordAdjustment(adjMsg);
	}

	public boolean isTenthRecord(int counter) {
		if (counter > 0 && counter % TEN == 0) {
			System.out.println("\n*** Reporting after 10th Message ***("+ counter + ")");
			return true;
		} else {
			return false;
		}
	}
	
	public boolean isFiftythRecord(int counter) {
		if (counter > 0 && counter % FIFTY == 0) {
			System.out.println("\n*** Paused processing. Can't take more messages ***"
					+ "\nPrinting Report after 50 Messages");
			return true;
		} else {
			return false;
		}
	}
}
