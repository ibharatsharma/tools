package com.jpmc.sales.processor;

import java.util.function.Function;

public class MessageTypeIdentifier implements Function<String[], String> {

	@Override
	public String apply(String[] msgArr) {
		
		if (msgArr.length > 0) {
			String firstWord = msgArr[0];
			
			if(AdjustmentType.has(firstWord)) {
				return "ADJUSTMENT";
			} else if (firstWord.matches("^\\d+")) {
				return "BULK";
			} else if (msgArr.length == 3 && msgArr[1].contains("at")) {
				return "SALE";
			}
		}
		return null;
	}

}
