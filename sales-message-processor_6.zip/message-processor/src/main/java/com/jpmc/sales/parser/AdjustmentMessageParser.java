package com.jpmc.sales.parser;

import com.jpmc.sales.domain.Item;

/**
 * Parses and Adjustment message
 * 
 * @author Bharat
 *
 */
public class AdjustmentMessageParser implements Parser {

	@Override
	public Item apply(String[] msgArr) {

		validateInput(msgArr, 3);

		Item m = new Item();
		m.setOperator(msgArr[0]);
		m.setProduct(parseType(msgArr[2]));
		m.setQuantity(0); // this is an adjustment msg
		m.setPrice(parsePrice(msgArr[1]));
		return m;
	}

}