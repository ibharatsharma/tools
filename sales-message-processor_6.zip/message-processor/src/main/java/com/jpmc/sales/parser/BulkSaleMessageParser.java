package com.jpmc.sales.parser;

import com.jpmc.sales.domain.Item;

/**
 * Parses a bulk message for a given quantity
 *  
 * @author Bharat
 *
 */
public class BulkSaleMessageParser implements Parser{

	@Override
	public Item apply(String[] msgArr) {
		
		validateInput(msgArr, 6);
		
		Item m = new Item();
		m.setProduct(parseType(msgArr[3]));
		m.setPrice(parsePrice(msgArr[5]));
		m.setQuantity(Integer.parseInt(msgArr[0]));
		
		return m;
	}

}