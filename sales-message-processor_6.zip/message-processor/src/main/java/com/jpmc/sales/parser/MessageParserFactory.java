package com.jpmc.sales.parser;

import java.util.Optional;
import java.util.function.Function;

import com.jpmc.sales.domain.Item;
import com.jpmc.sales.utils.Constants;

/**
 * Parser Factory for different type of messages.
 * 
 * @author Bharat
 *
 */
public class MessageParserFactory {

	public Optional<Function<String[], Item>> getParser(String msgType) {

		if ("".equals(msgType.trim())) {
			return Optional.empty();
		}

		Function<String[], Item> parser = null;

		if (msgType.equals(Constants.SALE)) {
			parser = new SaleMessageParser();
		} else if (msgType.equals(Constants.BULK)) {
			parser = new BulkSaleMessageParser();
		} else if (msgType.equals(Constants.ADJUSTMENT)) {
			parser = new AdjustmentMessageParser();
		}

		return Optional.of(parser);
	}
}
