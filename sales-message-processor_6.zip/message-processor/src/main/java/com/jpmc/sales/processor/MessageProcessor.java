package com.jpmc.sales.processor;

import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;

import com.jpmc.sales.domain.Item;
import com.jpmc.sales.parser.MessageParserFactory;
import com.jpmc.sales.reports.ConsoleReportPrinter;
import com.jpmc.sales.reports.ReportPrinter;
import com.jpmc.sales.store.SalesStore;
import com.jpmc.sales.store.SalesStoreImpl;
import com.jpmc.sales.utils.Constants;

/**
 * 
 * @author Bharat
 *
 */
public class MessageProcessor implements Consumer<String> {

	private static int counter = 0;
	private final MessageTypeIdentifier typeIdentifier;
	private final MessageParserFactory parserFactory;
	private final SalesStore store;
	private final ReportPrinter printer;
	private final AdjustmentService adjustmentService;

	public MessageProcessor() {
		this.typeIdentifier = new MessageTypeIdentifier();
		this.parserFactory = new MessageParserFactory();
		this.store = SalesStoreImpl.getInstance();
		this.printer = new ConsoleReportPrinter();
		this.adjustmentService = new AdjustmentService();
	}

	
	@Override
	public void accept(String msgStr) {

		msgStr = Objects.requireNonNull(msgStr, "A message cannot be null").toLowerCase();

		// Split string and find out type of message
		String[] msgArr = msgStr.split(Constants.SPACE_REGEX);

		// find out type of message
		String type = typeIdentifier.apply(msgArr);
		
		// get a parser
		Optional<Function<String[], Item>> parserOpt = this.parserFactory.getParser(type);

		// parse
		Function<String[], Item> parser = parserOpt
				.orElseThrow(() -> new ProcessingException("Unparseable type of message: " + type));

		// System.out.println(parser);
		Item item = parser.apply(msgArr);

		if (item.getOperator() == null) {
			store.saveItem(item);
		} else {
			// this is an adjustment message. should be applied to all products of given type.
			this.adjustmentService.handleAdjustmentMessage(item);
		}
		counter ++;
		
		
		doPrinting();
		
	}
	
	/**
	 * Invokes printer
	 */
	private void doPrinting() {
		
		if(adjustmentService.isTenthRecord(counter)) {
			printer.print(store.getAllItems());
		}
		
		if(adjustmentService.isFiftythRecord(counter)) {
			printer.printAdjustments(adjustmentService.getAdjustments());
			// 
			System.out.println("\nShutting down now...");
			System.exit(0);
		}
	}

}
