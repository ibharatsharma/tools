package com.jpmc.sales.domain;

import java.math.BigDecimal;

/**
 * The sale object representing one sale message.
 * 
 * @author Bharat
 *
 */
public class Item {

	private String product;
	private BigDecimal price;
	private int quantity;
	private String operator;
	
	public Item() {
	}
	
	public Item(String product, BigDecimal price, int quantity, String operator) {
		this.product = product;
		this.price = price;
		this.quantity = quantity;
		this.operator = operator;
	}

	public String getProduct() {
		return product;
	}
	
	public void setProduct(String product) {
		this.product = product;
	}
	
	public BigDecimal getPrice() {
		return price;
	}
	
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public String getOperator() {
		return operator;
	}
	
	public void setOperator(String operator) {
		this.operator = operator;
	}
	
	public BigDecimal total() {
		return price.multiply(BigDecimal.valueOf(quantity));
	}

	@Override
	public String toString() {
		return "Sale [product=" + product + ", price=" + price + ", quantity=" + quantity + ", operator=" + operator
				+ "]";
	}
	
}
