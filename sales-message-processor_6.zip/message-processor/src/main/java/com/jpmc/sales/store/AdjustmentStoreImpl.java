package com.jpmc.sales.store;

import java.util.ArrayList;
import java.util.List;

public class AdjustmentStoreImpl implements AdjustmentStore {

	private List<String> adjustments;
	
	public AdjustmentStoreImpl() {
		this.adjustments = new ArrayList<>();
	}
	
	public void recordAdjustment(String adjustment) {
		this.adjustments.add(adjustment);
	}
	
	public List<String> getAdjustments() {
		return this.adjustments;
	}
}
