package com.jpmc.sales.processor;

import java.math.BigDecimal;
import java.util.function.Function;

import com.jpmc.sales.domain.Item;

/**
 * Applies adjustment to given item.
 * 
 * @author Bharat
 *
 */
public class AdjustmentMaker implements Function<Item, Item>{

	private final BigDecimal ajustmentFactor; 
	private final String operation;
	
	public AdjustmentMaker(final BigDecimal ajustmentFactor, final String operation) {
		this.ajustmentFactor = ajustmentFactor;
		this.operation = operation;
	}
	

	@Override
	public Item apply(Item item) {
		try {
			doAjustment(item, ajustmentFactor, operation);
		} catch (ProcessingException e) {
			e.printStackTrace();
		}
		return item;
	}
	
	private void doAjustment(Item m, final BigDecimal factor, String operation) throws ProcessingException {

		switch (operation.toLowerCase()) {
		case "add":
			//m.setPrice(m.getPrice() + factor);
			m.setPrice(m.getPrice().add(factor));
			break;
		case "subtract":
			//m.setPrice(m.getPrice() - factor);
			m.setPrice(m.getPrice().subtract(factor));
			break;
		case "multiply":
			//m.setPrice(m.getPrice() * factor);
			m.setPrice(m.getPrice().multiply(factor));
			break;
		default:
			throw new ProcessingException(
					"Error: Unsupported operation: " + operation + ". Only add, subtract, multiply are supported.");
		}
	}
}
