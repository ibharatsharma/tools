package com.jpmc.sales.store;

import java.util.HashMap;
import java.util.Map;

import com.jpmc.sales.domain.Item;
import com.jpmc.sales.domain.Sale;

public class SalesStoreImpl implements SalesStore {

	private static SalesStoreImpl instance;
	
	private Map<String, Sale> store;

	private SalesStoreImpl() {
		store = new HashMap<>();
	}

	public static SalesStore getInstance() {
		if(instance == null) {
			instance = new SalesStoreImpl();
		}
		return instance;
	}
	
	@Override
	public void saveItem(Item m) {
		
		if (store.containsKey(m.getProduct())) {
			store.get(m.getProduct()).addItem(m);
		} else {
			Sale s = new Sale();
			s.addItem(m);
			store.put(m.getProduct(), s);
		}
		//System.out.println("product added to store: " + store);
	}

	@Override
	public Map<String, Sale> getAllItems() {
		return store;
	}

	@Override
	public Sale getSaleForItem(String name) {
		return store.get(name);
	}
}
