package com.jpmc.sales.parser;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.function.Function;

import com.jpmc.sales.domain.Item;
import com.jpmc.sales.processor.ProcessingException;

/**
 * The contract for parser
 * 
 * @author Bharat
 *
 */
public interface Parser extends Function<String[], Item>{

	default void validateInput(String[] msgArr, int minMsgArrSize) throws ProcessingException {
		if(msgArr == null || msgArr.length < minMsgArrSize ) {
			throw new ProcessingException("Invalid Sale message. Could not parse: " + Arrays.toString(msgArr));
		}
	}
	/**
	 * Takes care of extra p in price
	 * @param rawPrice
	 * @return
	 */
	default BigDecimal parsePrice(String priceStr) {
		
		BigDecimal price = new BigDecimal(priceStr.replaceAll("Â£|p", ""));
		if (!priceStr.contains(".")) {
			price = price.divide(new BigDecimal("100"));
		}
		return price;
	}
	
	/**
	 * Makes everything plural
	 * @param singularType
	 * @return
	 */
	default String parseType(String singularType) {
		String pluralType = "";
		String typeWithoutLastChar = singularType.substring(0, singularType.length() - 1);
		
		if (singularType.endsWith("o")) { // mango -> mangoes
			pluralType = String.format("%soes", typeWithoutLastChar);
		} else if (singularType.endsWith("y")) { // berry -> berries
			pluralType = String.format("%sies", typeWithoutLastChar);
		} else if (singularType.endsWith("h")) { // church -> churches
			pluralType = String.format("%shes", typeWithoutLastChar);
		} else if (!singularType.endsWith("s")) { // banana -> bananas
			pluralType = String.format("%ss", singularType);
		} else {
			// otherwise just append an s
			pluralType = String.format("%s", singularType);
		}
		return pluralType.toLowerCase();
	}
}
