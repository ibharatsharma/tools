package com.jpmc.sales.processor;

public enum AdjustmentType {
	add, subtract, multiply;
	
	public static boolean has(String type) {
		return type.equals(add.name()) || type.equals(subtract.name()) || type.equals(multiply.name());
	}
}
