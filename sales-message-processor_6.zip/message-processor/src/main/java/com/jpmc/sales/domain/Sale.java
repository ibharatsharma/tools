package com.jpmc.sales.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class Sale {

	private final List<Item> items;

	public Sale() {
		items = new ArrayList<>();
	}

	public int getTotalQuantity() {
		return items.stream()
				.mapToInt(i -> i.getQuantity())
				.sum();
	}

	public BigDecimal getTotalValue() {

		return this.items.stream()
			.filter(item -> item != null)
			.map(Item::total)
			.reduce(BigDecimal.ZERO, BigDecimal::add).setScale(2);
		
	}

	public void addItem(Item item) {
		items.add(item);
	}

	public void applyAdjustment(Function<Item, Item> func) {
		items.forEach(item -> func.apply(item));
	}

	@Override
	public String toString() {
		return "quantity: " + getTotalQuantity() + ", Value:" + getTotalValue();
	}
}
