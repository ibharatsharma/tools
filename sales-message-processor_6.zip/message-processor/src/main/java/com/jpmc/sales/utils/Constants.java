package com.jpmc.sales.utils;

public class Constants {

	public static final String ADJUSTMENT = "ADJUSTMENT";
	public static final String SALE = "SALE";
	public static final String BULK = "BULK";
	
	public static final String SPACE_REGEX = "\\s+";
	
	
}
