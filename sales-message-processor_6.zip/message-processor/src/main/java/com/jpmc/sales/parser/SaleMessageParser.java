package com.jpmc.sales.parser;

import com.jpmc.sales.domain.Item;

/**
 * Simple sale message parser
 * 
 * @author Bharat
 *
 */
public class SaleMessageParser implements Parser {

	@Override
	public Item apply(String[] msgArr) {
		
		validateInput(msgArr,3);
		
		Item m = new Item();
		m.setProduct(parseType(msgArr[0]));
		m.setPrice(parsePrice(msgArr[2]));
		m.setQuantity(1); // always 1
		return m;
	}

}
