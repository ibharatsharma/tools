package com.jpmc.sales.reports;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.jpmc.sales.domain.Sale;

/**
 * Prints Report to console
 * 
 * @author Bharat
 *
 */
public class ConsoleReportPrinter implements ReportPrinter {

	@Override
	public void print(Map<String, Sale> store) {

		BigDecimal total = BigDecimal.ZERO;
		System.out.println("-------------------------------------------------------");
		System.out.println(String.format("|%-30s|%11s|%10s|", "Item","Quantity","Value"));
		System.out.println("-------------------------------------------------------");
		for (Map.Entry<String, Sale> e : store.entrySet()) {
			System.out.println(String.format("|%-30s|%11d|%10.2f|", e.getKey(),
					e.getValue().getTotalQuantity(), e.getValue().getTotalValue()));
			total = total.add(e.getValue().getTotalValue()); 

		}
		System.out.println("-------------------------------------------------------");
		System.out.println(String.format("|%-42s|%10.2f|", "Total Sales",total));
		System.out.println("-------------------------------------------------------");

	}
	
	public void printAdjustments(List<String> adjustments) {
		System.out.println("------------------------------------------------------------------------------");
		System.out.println(String.format("|%-100s", "::Adjustment Report::"));
		System.out.println("------------------------------------------------------------------------------");
		adjustments.forEach( a -> {
			System.out.println(String.format("|%-100s", a));
		});
		System.out.println("------------------------------------------------------------------------------");
	}

}
