# Sales Message Processor

Sales message processor takes messages received in a file from third party vendor and processes it to generate reports.

File may contain 3 types of messages:
1. Single item sale message
1. Bulk item sale message
1. Price adjustment to existing sales

## Assumptions
1. The application is single threaded.
1. It does not handle thread synchronization in singleton pattern.
1. If an adjustment messages comes before sale of that item, then we simply ignore that message.
1. Test mocking api's not used to keep jars to minimum as stated in the problem statement.
1. Executable jar not created. Assuming user will import in Intellij/Eclipse and run the project.

## Code Coverage
1. 84% Code coverage

![Code Coverage](docs/code-coverage.PNG "Code Coverage")

## Build
From project's root directory run following Maven command:
 
	mvn clean install


## Running the Project
This project needs minimum java 8 JDK.

Run Main class `com\jpmc\sales\SalesProcessor.java` from your IDE.
 